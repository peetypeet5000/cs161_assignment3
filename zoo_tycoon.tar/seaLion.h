#ifndef LION
#define LION

#include <iostream>
#include <cstdlib>
#include "animal.h"

class SeaLion : public Animal {
    public:
    SeaLion();
    int getRev(bool);

};


#endif