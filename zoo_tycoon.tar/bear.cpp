#include "bear.h"

BlackBear::BlackBear() {
    offspring_count = 2;
    food_mult = 3;
    cost = 6000;
}