#ifndef UTILITY
#define UTILITY

#include <string>
#include <iostream>
#include <cmath>

int getInt();
bool checkRange(int, int, int);
bool isInt(std::string);

#endif