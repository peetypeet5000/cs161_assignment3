#include "tiger.h"

Tiger::Tiger() {
    offspring_count = 3;
    food_mult = 5;
    cost = 15000;
}