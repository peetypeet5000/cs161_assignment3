#ifndef BEAR
#define BEAR

#include "animal.h"

class BlackBear : public Animal {
    public:
    BlackBear();

};


#endif