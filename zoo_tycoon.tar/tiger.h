#ifndef TIGER
#define TIGER

#include <iostream>
#include "animal.h"

class Tiger : public Animal {
    public:
    Tiger();

};


#endif