#include "animal.h"

Animal::Animal() {
    age = 48;
}

void Animal::incrementAge() {
    age++;
}


int Animal::getFoodCost(int base) {
    return base * food_mult;
}


int Animal::getRev() {
    return cost * .1;
}


int Animal::getAge() {
    return age;
}
